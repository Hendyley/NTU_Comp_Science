package AdminModule;

public class Holiday{
    private String date;

    public Holiday(String date){
        this.date = date;
    }

    public String getDate(){
        return this.date;
    }
}
