package MovieGoerModule;

public enum AgeOfMovieGoer {
    CHILD, STUDENT, SENIOR, ADULT
}
