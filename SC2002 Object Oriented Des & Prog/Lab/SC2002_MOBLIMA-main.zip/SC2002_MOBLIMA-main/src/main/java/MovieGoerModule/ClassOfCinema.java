package MovieGoerModule;

public enum ClassOfCinema {
    PLATINUM, REGULAR, DOLBY
}
