package MovieGoerModule;

public enum Day {
    MON_TO_WED, THURS, FRI_BEFORE_6, HOLIDAY, REMAINING_DAYS
}
