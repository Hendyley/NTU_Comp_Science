package MovieGoerModule;

public enum Role {
        ADMIN, MOVIEGOER
}
