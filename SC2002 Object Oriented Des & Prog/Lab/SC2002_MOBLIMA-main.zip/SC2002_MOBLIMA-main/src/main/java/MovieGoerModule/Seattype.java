package MovieGoerModule;

public enum Seattype {
    COUPLE_SEAT, ELITE_SEAT, ULTIMA_SEAT, SEAT;
}
