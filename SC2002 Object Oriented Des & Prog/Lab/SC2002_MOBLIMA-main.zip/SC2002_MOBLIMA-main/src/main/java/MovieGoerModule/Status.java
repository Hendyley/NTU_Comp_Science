package MovieGoerModule;

public enum Status {
    COMING_SOON, PREVIEW, NOW_SHOWING, END_OF_SHOWING
}
