package MovieGoerModule;

public enum TypeOfMovie {
    REGULAR_2D, REGULAR_3D, BLOCKBUSTER_2D, BLOCKBUSTER_3D
}
