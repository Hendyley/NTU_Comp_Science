package com.ntuproject.fast_and_furious;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Parking_Custom_ListView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_custom_list_view);
    }
}