package com.ntuproject.fast_and_furious;

import java.util.List;

//import okhttp3.Route;

public class Result {

    private List<Route>  routes;
    private String  status;

    public  List<Route> getRoutes() {return routes;}

    public void setRoutes(List<Route> routes) {this.routes = routes;}

    public String getStatus() {return  status;}

    public void setStatus(String status) { this.status = status;}

}
