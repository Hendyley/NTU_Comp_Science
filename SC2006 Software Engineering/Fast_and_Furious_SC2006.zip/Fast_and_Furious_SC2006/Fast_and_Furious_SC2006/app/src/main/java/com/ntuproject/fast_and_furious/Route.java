package com.ntuproject.fast_and_furious;

public class Route {

    private OverviewPolyline overview_Polyline;

    public OverviewPolyline getOverviewPolyline() { return overview_Polyline;}

    public void  setOverviewPolyline(OverviewPolyline overviewPolyline){
        this.overview_Polyline = overviewPolyline;
    }
}
